package com.ethan.test1.utils;

import java.util.Random;

public class Utils {
	public int getTime() {
		int time = 0;
		time = new Random().nextInt(10);
		return time;
	}

	public int getLength() {
		int length = 0;
		Random random = new Random();
		length = random.nextInt(11) % 11 + 10;
		return length;
	}

	public int getPrior() {
		int prior = 0;
		prior = new Random().nextInt(10);
		return prior;
	}

}
