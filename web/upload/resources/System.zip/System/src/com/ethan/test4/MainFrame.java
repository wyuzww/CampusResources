package com.ethan.test4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Enumeration;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreePath;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import java.awt.FlowLayout;
import javax.swing.JSplitPane;

public class MainFrame extends JFrame {
	FileMouseListener mouseListener;
	ExpandListener expandListener;
	private static final long serialVersionUID = 1L;
	public String PPath = null;
	public String currentPath = null;
	ExpandListener cmd = new ExpandListener(this);
	JTree tree;
	public JTextField addfile;
	public JButton btnaddf;
	public JButton btnaddd;
	public JButton btnmvd;
	public JTextField mvfile;
	public JButton btnmvf;
	public JLabel addrs;
	public JLabel mvrs;
	public JTextArea fileshow;
	public JTextArea filestyle;
	private JTextField textField;

	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("实验四：文件管理");
		setBounds(100, 100, 1000, 500);
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.NORTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		textField = new JTextField();
		JLabel lblNewLabel = new JLabel("地址：");
		lblNewLabel.setEnabled(false);
		textField.setEditable(false);
		textField.setColumns(50);

		JSplitPane splitPane = new JSplitPane();
		splitPane.setLeftComponent(lblNewLabel);
		splitPane.setRightComponent(textField);
		panel.add(splitPane);

		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		DefaultMutableTreeNode top = new DefaultMutableTreeNode("我的电脑");
		tree = new JTree(top);
		addChildren(cmd.ListDisks(), top);
		mouseListener = new FileMouseListener();// 添加树的监听器;
		tree.addMouseListener(mouseListener);
		expandListener = new ExpandListener(this);
		tree.addTreeWillExpandListener(expandListener);
		JScrollPane scrollPane = new JScrollPane();
		panel_1.setLayout(new BorderLayout(0, 0));
		scrollPane = new JScrollPane();
		scrollPane.setViewportView(tree);
		tree.expandRow(0);
		panel_1.add(scrollPane);

		JPanel panel_2 = new JPanel();
		getContentPane().add(panel_2, BorderLayout.EAST);
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		fileshow = new JTextArea();
		fileshow.setRows(19);
		fileshow.setColumns(50);
		panel_2.add(fileshow);

		filestyle = new JTextArea();
		filestyle.setRows(19);
		filestyle.setColumns(20);
		panel_2.add(filestyle);

		JPanel panel_3 = new JPanel();
		getContentPane().add(panel_3, BorderLayout.SOUTH);

		JButton btnNewButton = new JButton("新建文件（夹）");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cmd.addframe();
			}
		});
		panel_3.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("删除文件（夹）");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cmd.del();
			}
		});
		panel_3.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("修改文件（夹）名");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cmd.mvframe();
			}
		});
		panel_3.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("刷新当前目录");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		panel_3.add(btnNewButton_3);
	}

	/**
	 *
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MainFrame mainFrame = new MainFrame();
			mainFrame.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * 往node节点下添加一个子节点obj;
	 */
	public void addChild(Object obj, DefaultMutableTreeNode node) {
		if (obj != null && node != null) {
			DefaultMutableTreeNode temp = new DefaultMutableTreeNode(obj);
			if (node.getAllowsChildren())
				node.add(temp);
			if (!((String) obj).equals("A:\\") && ((String) obj).length() <= 3)// 防止读取A软驱,会出现异常;用于初始用的;
				addChildren(cmd.listAll((String) obj), temp);
		}
	}

	/*
	 * 在node节点下添加数组children;
	 */
	public void addChildren(String[] children, DefaultMutableTreeNode node) {
		if (children != null && node != null) {
			for (int i = 0; i < children.length; i++) {
				addChild(children[i], node);
			}
		}
	}

	/*
	 * 对树的节点进行预提取;
	 */
	public void addPrefetchChildren(String path, DefaultMutableTreeNode node) {
		addChildren(cmd.listDirectory(path), node);
	}

	/*
	 * 对路径路径进行连接;(已经获得了所有的整个路径,需要量转化)
	 */
	public String toFilePath(String str) {
		// 先去掉头尾的[];
		String pa = str.substring(1, str.length() - 1);
		String[] temp = pa.split(", ");
		String path = "";
		for (int i = 1; i < temp.length; i++) {
			if (!path.endsWith("\\") && !path.equals(""))// 不为空是为去根节点;
				path += "\\";
			path += temp[i];
		}
		return path;
	}

	public String toPFilePath(String str) {
		// 先去掉头尾的[];
		String pa = str.substring(1, str.length() - 1);
		String[] temp = pa.split(", ");
		String path = "";
		for (int i = 1; i < temp.length - 1; i++) {
			if (!path.endsWith("\\") && !path.equals(""))// 不为空是为去根节点;
				path += "\\";
			path += temp[i];
		}
		return path;
	}

	public class ExpandListener implements TreeWillExpandListener, ActionListener {
		/*
		 * 树展开及收缩监听;
		 */
		private MainFrame mainFrame = null;

		public ExpandListener(MainFrame mainFrame) {
			this.mainFrame = mainFrame;
		}

		@Override
		public void treeWillExpand(TreeExpansionEvent event) {
			// 对节点的路径进行转化
			String path = toFilePath(event.getPath().toString());
			TreePath treePath = event.getPath();
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) treePath.getLastPathComponent();
			if (node.getDepth() < 2) {
				Enumeration children = node.children();
				String filePath = "";
				while (children.hasMoreElements()) {
					DefaultMutableTreeNode temp = (DefaultMutableTreeNode) children.nextElement();
					filePath = "";
					filePath = path;
					if (!filePath.endsWith("\\"))
						filePath += "\\";
					filePath += temp.toString();
					mainFrame.addPrefetchChildren(filePath, temp);
				}
			}
		}

		public void addframe() {
			JFrame addFrame = new JFrame();
			JLabel jlbl = new JLabel("请输入要添加的文件(夹)名:");
			addrs = new JLabel("");
			addrs.setBounds(180, 10, 100, 25);
			jlbl.setBounds(10, 10, 170, 25);
			addfile = new JTextField();
			addfile.setBounds(10, 40, 260, 25);
			btnaddf = new JButton("添加文件");
			btnaddd = new JButton("添加文件夹");
			btnaddf.setBounds(20, 80, 100, 25);
			btnaddd.setBounds(160, 80, 100, 25);
			btnaddf.addActionListener(this);
			btnaddd.addActionListener(this);
			addFrame.getContentPane().add(jlbl);
			addFrame.getContentPane().add(addrs);
			addFrame.getContentPane().add(addfile);
			addFrame.getContentPane().add(btnaddf);
			addFrame.getContentPane().add(btnaddd);
			addFrame.setBounds(400, 350, 300, 150);
			addFrame.setTitle("添加文件(夹)");
			addFrame.getContentPane().setLayout(null);
			addFrame.setVisible(true);
		}

		public void mvframe() {
			JFrame mvFrame = new JFrame();
			JLabel jlbl = new JLabel("请输入修改后的文件名:");
			mvrs = new JLabel("");
			mvrs.setBounds(160, 10, 140, 25);
			jlbl.setBounds(10, 10, 170, 25);
			mvfile = new JTextField();
			mvfile.setBounds(10, 40, 260, 25);
			btnmvf = new JButton("修改文件名");
			btnmvd = new JButton(" 修改文件夹名");
			btnmvf.setBounds(10, 80, 120, 25);
			btnmvd.setBounds(150, 80, 120, 25);
			btnmvf.addActionListener(this);
			btnmvd.addActionListener(this);
			mvFrame.getContentPane().add(jlbl);
			mvFrame.getContentPane().add(mvrs);
			mvFrame.getContentPane().add(mvfile);
			mvFrame.getContentPane().add(btnmvf);
			mvFrame.getContentPane().add(btnmvd);
			mvFrame.setBounds(400, 350, 300, 150);
			mvFrame.setTitle("修改文件（夹）名");
			mvFrame.getContentPane().setLayout(null);
			mvFrame.setVisible(true);
		}

		public String[] ListDisks() {
			File roots[] = File.listRoots();// 根盘符;
			String disks[] = new String[roots.length];
			for (int i = 0; i < roots.length; i++) {
				disks[i] = roots[i].toString();
			}
			return disks;
		}

		public String[] listAll(String path) {
			try {
				File f = new File(path);
				String[] fileName;
				String tmp = null;
				mainFrame.fileshow.setText(null);
				mainFrame.filestyle.setText(null);
				if (f.isDirectory()) {
					fileName = f.list();
					// System.out.println("共有" + fileName.length + "个文件");
					for (int i = 0; i < fileName.length; i++) {
						mainFrame.fileshow.append(fileName[i] + '\n');
						tmp = path + '\\' + fileName[i];
						// System.out.println(tmp);
						if (listDirectory(tmp) != null) {
							mainFrame.filestyle.append("文件夹\n");
						} else {
							mainFrame.filestyle.append("文件\n");
						}
					}
					return fileName;
				} else if (f.isFile()) {
					System.out.println("这是一个文件");
					return null;
				} else {
					return null;
				}
			} catch (Exception e) {
				return null;
			}
		}

		public String[] listDirectory(String path) {
			File f = new File(path);
			String[] fileName;
			if (f.isDirectory()) {
				fileName = f.list();
				return fileName;
			} else {
				return null;
			}
		}

		public void md(String directory) {
			if (!mainFrame.currentPath.equals("")) {
				String temp = mainFrame.currentPath + "\\" + directory;
				File newFile = new File(temp);
				if (!newFile.exists()) {
					try {
						if (newFile.isDirectory() == false) {
							newFile.mkdirs();
							System.out.println("文件夹创建成功!");
						} else {
							System.out.println("文件夹创建出错!");
						}
					} catch (Exception e) {
						System.out.println("出错信息:" + e.getMessage());
					}
				} else {
					System.out.println("文件夹已经存在");
				}
			}
		}

		public void del() {
			String temp = mainFrame.currentPath;
			File file = new File(temp);
			if (file.exists()) {
				if (file.delete()) {
					mainFrame.fileshow.setText("文件(夹)删除成功!");
				} else {
					mainFrame.fileshow.setText("文件(夹)删除操作出错!");
				}
			} else {
				mainFrame.fileshow.setText("文件(夹)不存在");
			}
		}

		public void edit(String file) {
			if (!mainFrame.currentPath.equals("")) {
				String temp = mainFrame.currentPath + "\\" + file;
				File newFile = new File(temp);
				if (newFile.exists()) {
					mainFrame.addrs.setText("文件已经存在!");
					System.out.println("文件已经存在!");
				} else {
					try {
						newFile.createNewFile();
						mainFrame.addrs.setText("文件创建成功!");
						System.out.println("文件创建成功!");
					} catch (Exception e) {
						System.out.println("文件创建失败:" + e.getMessage());
					}
				}
			}
		}

		public void mvf(String file) {
			if (!mainFrame.PPath.equals("")) {
				String temp = mainFrame.PPath + "\\" + file;
				File newFile = new File(mainFrame.currentPath);
				if (newFile.exists()) {
					if (newFile.renameTo(new File(temp)) == true) {
						mainFrame.mvrs.setText("修改文件名成功!");
					} else {
						mainFrame.mvrs.setText("存在同名文件!");
					}
				}
			}
		}

		public void mvd(String dir) {
			if (!mainFrame.PPath.equals("")) {
				String temp = mainFrame.PPath + "\\" + dir;
				File newFile = new File(mainFrame.currentPath);
				if (newFile.exists()) {
					if (newFile.renameTo(new File(temp)) == true) {
						mainFrame.mvrs.setText("修改文件夹名成功!");
					} else {
						mainFrame.mvrs.setText("存在同名文件夹!");
					}
				}

			}
		}

		@Override
		public void treeWillCollapse(TreeExpansionEvent event) throws ExpandVetoException {
			// TODO 自动生成的方法存根

		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO 自动生成的方法存根
			if (e.getSource() == btnaddf) {
				cmd.edit(addfile.getText().toString());
			} else if (e.getSource() == btnaddd) {
				cmd.md(addfile.getText().toString());
			} else if (e.getSource() == btnmvd) {
				cmd.mvd(mvfile.getText().toString());
			} else if (e.getSource() == btnmvf) {
				cmd.mvf(mvfile.getText().toString());
			}
		}
	}

	public class FileMouseListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
		}

		public void mouseRleased(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {
			JTree tree = (JTree) e.getSource();
			int selRow = tree.getRowForLocation(e.getX(), e.getY());
			TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
			if (tree.isExpanded(selPath))
				tree.collapsePath(selPath);
			else
				tree.expandPath(selPath);
			if (selRow != -1) {
				if (e.getClickCount() == 1) {
					textField.setText(toFilePath(selPath.toString()));
					currentPath = toFilePath(selPath.toString());
					PPath = toFilePath(selPath.toString());
					cmd.listAll(currentPath);
				} else if (e.getClickCount() == 2) {
				}
			}
		}

		/*
		 * 对路径路径进行连接;(已经获得了所有的整个路径,需要量转化)
		 */
		public String toFilePath(String str) {
			// 先去掉头尾的[];
			String pa = str.substring(1, str.length() - 1);
			String[] temp = pa.split(", ");
			String path = "";
			for (int i = 1; i < temp.length; i++) {
				path += temp[i];
			}
			return path;
		}
	}
}
