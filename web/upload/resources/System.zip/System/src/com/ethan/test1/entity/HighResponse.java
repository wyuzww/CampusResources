package com.ethan.test1.entity;

public class HighResponse {
	private String name;
	private String status;
	private int time;
	private int ratio;
	private int length;
	private int complete;

	public HighResponse() {

	}

	public HighResponse(String name, String status, int time, int ratio, int length, int complete) {
		super();
		this.name = name;
		this.status = status;
		this.time = time;
		this.ratio = ratio;
		this.length = length;
		this.complete = complete;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getRatio() {
		return ratio;
	}

	public void setRatio(int ratio) {
		this.ratio = ratio;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getComplete() {
		return complete;
	}

	public void setComplete(int complete) {
		this.complete = complete;
	}

}
