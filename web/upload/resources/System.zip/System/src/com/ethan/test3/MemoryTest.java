package com.ethan.test3;

import java.util.Random;
import java.util.Scanner;

public class MemoryTest {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		boolean Choose = true;
		String C;
		Scanner in;
		Memory memory = new Memory();
		System.out.println("初始化进程...");
		System.out.println("以 <<最先适配算法>>创建4个进程!");
		for (int i = 0; i < 4; i++) {
			memory.allocation(new Random().nextInt(251) + 50);
		}
		memory.showZones();
		while (Choose == true) {
			in = new Scanner(System.in);
			System.out.println("请选择：");
			System.out.println("1.创建进程\t 2.回收进程分区");
			int choose = in.nextInt();
			switch (choose) {
			case 1:
				System.out.println("输入进程大小(KB)：");
				in = new Scanner(System.in);
				int size = in.nextInt();
				memory.allocation(size);
				memory.showZones();
				break;
			case 2:
				System.out.println("输入要回收的进程分区id：");
				in = new Scanner(System.in);
				int id = in.nextInt();
				memory.collection(id);
				memory.showZones();
				break;
			}
			System.out.println("您是否还要进行：y/n?");
			in = new Scanner(System.in);
			C = in.nextLine();
			if (C.endsWith("n")) {
				Choose = false;
			}
		}
		System.out.println("END!");
	}

}
