package com.ethan.test1;

import java.awt.Component;
import javax.swing.JProgressBar;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class MyProgressCellRenderer extends JProgressBar implements TableCellRenderer {
	/** the progress bar's color. */

	// private Hashtable<Integer, Color> limitColors = null;

	/**
	 * 
	 */
	private static final long serialVersionUID = 5788698831495619849L;

	/**
	 * 
	 * Creates a progress bar using the specified orientation, * minimum, and
	 * maximum.
	 * 
	 */

	public MyProgressCellRenderer(int min, int max) {

		super(JProgressBar.HORIZONTAL, min, max);

		setBorderPainted(false);

	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		// TODO 自动生成的方法存根
		int n = 0;
		if (!(value instanceof Number)) {
			String str;
			if (value instanceof String) {
				str = (String) value;
			} else {
				str = value.toString();
			}
			try {
				n = Integer.valueOf(str).intValue();
			} catch (NumberFormatException ex) {
			}
		} else {
			n = ((Number) value).intValue();
		}

		setValue(n);

		return this;
	}

}
