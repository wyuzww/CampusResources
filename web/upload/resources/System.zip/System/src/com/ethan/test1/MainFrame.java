package com.ethan.test1;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import com.ethan.test1.entity.StaticPriority;
import com.ethan.test1.entity.HighResponse;
import com.ethan.test1.entity.ShortWork;
import com.ethan.test1.utils.Utils;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class MainFrame extends JFrame {
	private JTabbedPane tabbedPane;
	private JTable table;
	private JScrollPane scrollPane;
	private JPanel shortWorkPanel;
	private JPanel staticPriorityPanel;
	private JPanel highestRespnsePanel;
	private boolean isChange = false;
	private boolean isOver = true;
	private boolean isbegin = false;
	private int time = 0;
	private int progessTime = -1;
	private static final long serialVersionUID = 1L;

	/**
	 *
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MainFrame frame = new MainFrame();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setTitle("操作系统实验一   by: 3116004259钟文武");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 858, 454);
		setLayout(new BorderLayout());
		initPanel();
		initTabbedPane();

	}

	private void initPanel() {
		shortWork();
		staticPriority();
		highResponse();
	}

	private void initTabbedPane() {
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("短作业优先调度", shortWorkPanel);
		tabbedPane.addTab("静态优先权调度", staticPriorityPanel);
		tabbedPane.addTab("高响应比优先调度", highestRespnsePanel);
		tabbedPane.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				isChange = true;
				if (table != null) {
					scrollPane.removeAll();
				}
			}
		});
		getContentPane().add(tabbedPane);
	}

	private void shortWork() {
		if (shortWorkPanel == null) {
			shortWorkPanel = new JPanel();
			JButton button = new JButton("新建作业");
			JLabel text = new JLabel("每个作业的长度都为50-100间的随机值，每个作业的到达时间都为0-10间的随机值。");
			JLabel timer = new JLabel("请新建作业");
			JLabel runtime = new JLabel("运行时间：");
			JLabel overflag = new JLabel("作业已完成");
			shortWorkPanel.add(overflag).setVisible(false);
			shortWorkPanel.add(runtime).setVisible(false);
			shortWorkPanel.add(timer).setVisible(false);
			shortWorkPanel.add(button);
			shortWorkPanel.add(text);
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Object[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
					Object value = JOptionPane.showInputDialog(shortWorkPanel, "请选择新建的作业数量", "新建作业",
							JOptionPane.PLAIN_MESSAGE, null, values, values[0]);
					if (value != null) {
						button.setEnabled(false);
						newJob();
						int n = (int) value;
						newShortWork(n);
						startTimer(timer, runtime, overflag, button);
						shortWorkPanel.updateUI();
					}
				}
			});
		}
	}

	private void staticPriority() {
		if (staticPriorityPanel == null) {
			staticPriorityPanel = new JPanel();
			JButton button = new JButton("新建作业");
			JLabel text = new JLabel("每个作业的长度都为50-100间的随机值，到达时间都为0-10间的随机值，优先级都为0-10间随机值。");
			JLabel timer = new JLabel("请新建作业");
			JLabel runtime = new JLabel("运行时间：");
			JLabel overflag = new JLabel("作业已完成");
			staticPriorityPanel.add(overflag).setVisible(false);
			staticPriorityPanel.add(runtime).setVisible(false);
			staticPriorityPanel.add(timer).setVisible(false);
			staticPriorityPanel.add(button);
			staticPriorityPanel.add(text);
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Object[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
					// TODO 自动生成的方法存根
					Object value = JOptionPane.showInputDialog(staticPriorityPanel, "请选择新建的作业数量", "新建作业",
							JOptionPane.PLAIN_MESSAGE, null, values, values[0]);
					if (value != null) {
						button.setEnabled(false);
						newJob();
						int n = (int) value;
						newStaticPriority(n);
						startTimer(timer, runtime, overflag, button);
						staticPriorityPanel.updateUI();
					}
				}
			});
		}
	}

	private void highResponse() {
		if (highestRespnsePanel == null) {
			highestRespnsePanel = new JPanel();
			JLabel timer = new JLabel("请新建作业");
			JLabel runtime = new JLabel("运行时间：");
			JLabel overflag = new JLabel("作业已完成" + time + "s");
			JButton button = new JButton("新建作业");
			JLabel text = new JLabel("每个作业的长度都为50-100间的随机值，每个作业的到达时间都为0-10间的随机值。");
			highestRespnsePanel.add(overflag).setVisible(false);
			highestRespnsePanel.add(runtime).setVisible(false);
			highestRespnsePanel.add(timer).setVisible(false);
			highestRespnsePanel.add(button);
			highestRespnsePanel.add(text);
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Object[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
					Object value = JOptionPane.showInputDialog(highestRespnsePanel, "请选择新建的作业数量", "新建作业",
							JOptionPane.PLAIN_MESSAGE, null, values, values[0]);
					if (value != null) {
						button.setEnabled(false);
						newJob();
						int n = (int) value;
						newHighResponse(n);
						startTimer(timer, runtime, overflag, button);
						highestRespnsePanel.updateUI();
					}
				}
			});
		}
	}

	private void newShortWork(int n) {
		Object[][] rowData = new Object[n][5];
		for (int i = 0; i < n; i++) {
			ShortWork shortWork = new ShortWork("作业" + (i + 1), "未到达", new Utils().getTime(), new Utils().getLength(),
					0);
			rowData[i][0] = shortWork.getName();
			rowData[i][1] = shortWork.getStatus();
			rowData[i][2] = shortWork.getTime();
			rowData[i][3] = shortWork.getLength();
			rowData[i][4] = shortWork.getComplete();
		}
		// 创建表格中的横标题
		String[] Names = { "作业名", "作业状态", "到达时间(s)", "作业长度", "进度" };
		if (table != null) {
			scrollPane.removeAll();
			shortWorkPanel.remove(scrollPane);
		}
		table = new JTable(rowData, Names);
		initMyProgress(-1);
		// 设置此表视图的首选大小
		table.setEnabled(false);
		table.setPreferredScrollableViewportSize(new Dimension(800, 500));
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(500);
		scrollPane = new JScrollPane(table);
		shortWorkPanel.add(scrollPane);
		updateData(rowData, n, table, 4, 1);
		table.repaint();
	}

	private void newStaticPriority(int n) {
		Object[][] rowData = new Object[n][6];
		for (int i = 0; i < n; i++) {
			StaticPriority staticPriority = new StaticPriority("作业" + (i + 1), "未到达", new Utils().getTime(),
					new Utils().getPrior(), new Utils().getLength(), 0);
			rowData[i][0] = staticPriority.getName();
			rowData[i][1] = staticPriority.getStatus();
			rowData[i][2] = staticPriority.getTime();
			rowData[i][3] = staticPriority.getPrior();
			rowData[i][4] = staticPriority.getLength();
			rowData[i][5] = staticPriority.getComplete();
		}
		// 创建表格中的横标题
		String[] Names = { "作业名", "作业状态", "到达时间(s)", "作业优先级", "作业长度", "进度" };
		if (table != null) {
			scrollPane.removeAll();
			staticPriorityPanel.remove(scrollPane);
		}
		table = new JTable(rowData, Names);
		initMyProgress(1);
		// 设置此表视图的首选大小
		table.setEnabled(false);
		table.setPreferredScrollableViewportSize(new Dimension(800, 500));
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(5).setPreferredWidth(500);
		scrollPane = new JScrollPane(table);
		staticPriorityPanel.add(scrollPane);
		updateData(rowData, n, table, 5, 3);
		table.repaint();
	}

	private void newHighResponse(int n) {
		Object[][] rowData = new Object[n][6];
		for (int i = 0; i < n; i++) {
			HighResponse highResponse = new HighResponse("作业" + (i + 1), "未到达", new Utils().getTime(), 100,
					new Utils().getLength(), 0);
			rowData[i][0] = highResponse.getName();
			rowData[i][1] = highResponse.getStatus();
			rowData[i][2] = highResponse.getTime();
			rowData[i][3] = highResponse.getRatio();
			rowData[i][4] = highResponse.getLength();
			rowData[i][5] = highResponse.getComplete();
		}
		// 创建表格中的横标题
		String[] columnData = { "作业名", "作业状态", "到达时间(s)", "作业响应比(%)", "作业长度", "进度" };
		if (table != null) {
			scrollPane.removeAll();
			highestRespnsePanel.remove(scrollPane);
		}
		table = new JTable(rowData, columnData);
		initMyProgress(1);
		// 设置此表视图的首选大小
		table.setEnabled(false);
		table.setPreferredScrollableViewportSize(new Dimension(800, 500));
		table.getColumnModel().getColumn(0).setPreferredWidth(100);
		table.getColumnModel().getColumn(1).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(5).setPreferredWidth(500);
		scrollPane = new JScrollPane(table);
		highestRespnsePanel.add(scrollPane);
		updateData(rowData, n, table, 5, 3);
		updateRadio(rowData, n, table);
		table.repaint();
	}

	private void initMyProgress(int type) {
		MyProgressCellRenderer renderer = new MyProgressCellRenderer(0, 100);
		renderer.setStringPainted(true);
		renderer.setBackground(table.getBackground());
		// set renderer
		if (type > 0) {
			table.getColumnModel().getColumn(5).setCellRenderer(renderer);
		} else {
			table.getColumnModel().getColumn(4).setCellRenderer(renderer);
		}
	}

	private void startTimer(JLabel timer, JLabel runtime, JLabel overflag, JButton button) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				overflag.setVisible(false);
				runtime.setVisible(true);
				timer.setVisible(true);
				progessTime = -1;
				for (int i = 0; !isOver && !isChange; i++) {
					try {
						time = i;
						progessTime++;
						timer.setText((time) + " s");
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				overflag.setText("作业已完成，用时" + time + "s");
				overflag.setVisible(true);
				runtime.setVisible(false);
				timer.setVisible(false);
				button.setEnabled(true);
			}
		}).start();
	}

	private void updateData(Object[][] rowData, int n, JTable table, int position, int type) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (time + 1 <= 10) {
					for (int i = 0; i < n; i++) {
						if (time >= (Integer) rowData[i][2] && rowData[i][1].equals("未到达")) {
							rowData[i][1] = "就绪";
						}
						table.repaint();
					}
				}
			}
		}).start();
		new Thread(new Runnable() {
			@Override
			public void run() {
				isbegin = false;
				while (!isOver) {
					int max = getMax(rowData, n, type);
					for (int i = 0; !isOver && i < n; i++) {
						if ((Integer) rowData[i][3] == max && rowData[i][1].equals("就绪") && !isbegin) {
							rowData[i][1] = "CPU执行";
							isbegin = true;
							table.repaint();
							while ((Integer) rowData[i][position] < 100) {
								rowData[i][position] = (progessTime - (Integer) rowData[i][2]) * 100
										/ (Integer) rowData[i][position - 1];
								if ((Integer) rowData[i][position] >= 100) {
									rowData[i][position] = 100;
									rowData[i][1] = "完成";
									isbegin = false;
									progessTime = 0;
									nextJob(rowData, n, position, type);
									checkOver(rowData, n, position);
									return;

								}
								table.repaint();
							}
						}
						table.repaint();
					}
				}
			}
		}).start();
	}

	private void updateRadio(Object[][] rowData, int n, JTable table) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (!isOver) {
					for (int i = 0; i < n; i++) {
						if (rowData[i][1].equals("就绪")) {
							int ratio = (100 + ((time - (Integer) rowData[i][2]) * 100 / (Integer) rowData[i][4]));
							rowData[i][3] = ratio;
						}
						table.repaint();
					}
				}

			}
		}).start();
	}

	private void nextJob(Object[][] rowData, int n, int position, int type) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				isbegin = false;
				while (!isOver) {
					int max = getMax(rowData, n, type);
					for (int i = 0; !isOver && i < n; i++) {
						if ((Integer) rowData[i][3] == max && rowData[i][1].equals("就绪") && !isbegin) {
							rowData[i][1] = "CPU执行";
							isbegin = true;
							table.repaint();
							while ((Integer) rowData[i][position] < 100) {
								rowData[i][position] = (progessTime) * 100 / (Integer) rowData[i][position - 1];
								if ((Integer) rowData[i][position] >= 100) {
									rowData[i][position] = 100;
									rowData[i][1] = "完成";
									progessTime = 0;
									isbegin = false;
									nextJob(rowData, n, position, type);
									return;
								}
								table.repaint();
							}
						}
					}
					return;
				}
			}
		}).start();
	}

	private void checkOver(Object[][] rowData, int n, int position) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (!isOver) {
					boolean flag = true;
					for (int i = 0; i < n; i++) {
						if ((Integer) rowData[i][position] < 100) {
							flag = false;
						}
					}
					if (flag) {
						isOver = true;
						for (int i = 0; i < n; i++) {
							rowData[i][1] = "完成";
						}
					}
				}
			}
		}).start();
	}

	private void newJob() {
		progessTime = -1;
		isChange = false;
		isOver = false;
		time = 0;
	}

	private int getMax(Object[][] rowData, int n, int type) {
		int result = 0;
		if (type == 1) {
			int min = 100;
			for (int i = 0; i < n; i++) {
				if ((Integer) rowData[i][3] < min && rowData[i][1].equals("就绪")) {
					min = (Integer) rowData[i][3];
				}
			}
			result = min;
		} else {
			int max = 0;
			for (int i = 0; i < n; i++) {
				if ((Integer) rowData[i][3] > max && rowData[i][1].equals("就绪")) {
					max = (Integer) rowData[i][3];
				}
			}
			result = max;
		}
		return result;
	}
}
