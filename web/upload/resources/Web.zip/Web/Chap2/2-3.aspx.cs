﻿using System;
public partial class chap2_2_3 : System.Web.UI.Page
{
  protected void btnSubmit_Click(object sender, EventArgs e)
  {
    lblMessage.Text = "不管您输什么，我都喜欢ASP.NET!";
  }
} 