﻿function message() {
  alert("在外部2-8.js中");
} 