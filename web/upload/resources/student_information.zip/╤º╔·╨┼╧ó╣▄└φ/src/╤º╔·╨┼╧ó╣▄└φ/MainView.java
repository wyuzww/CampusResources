package 学生信息管理;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Window.Type;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 学生信息管理 主界面
 * 
 * @author 508工作室
 *
 */
public class MainView {
	private JFrame frame;
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	private static JTextField textField_4;
	private static JTextField textField_5;
	private static JTextField textField_6;
	private static JTextField textField_7;
	private static JTextField textField_8;

	public MainView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);

		frame.addWindowListener(new WindowAdapter() { // 鼠标点击关闭时
			@Override
			public void windowClosing(WindowEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "是否退出程序？", "退出程序", JOptionPane.YES_NO_OPTION);
				if (result == 0)
					Operation.exit(Operation.getSt(), Operation.getConn());
				else
					frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		});
		frame.getContentPane().setBackground(SystemColor.menu);
		frame.setBackground(Color.GRAY);
		frame.setType(Type.POPUP);
		frame.setTitle("学生信息管理");
		frame.setBounds(100, 100, 687, 452);
		frame.setLocationRelativeTo(null); // 视图居中
		// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel label = new JLabel("管理界面");
		label.setBounds(277, 0, 104, 27);
		label.setFont(new Font("华文楷体", Font.BOLD, 25));
		frame.getContentPane().add(label);

		JSeparator separator = new JSeparator();
		separator.setToolTipText("");
		separator.setBounds(10, 37, 661, 2);
		frame.getContentPane().add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setToolTipText("");
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(340, 37, 2, 344);
		frame.getContentPane().add(separator_1);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 379, 661, 2);
		frame.getContentPane().add(separator_2);

		JSeparator separator_3 = new JSeparator();
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setBounds(71, 36, 2, 345);
		frame.getContentPane().add(separator_3);

		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(340, 93, 331, 2);
		frame.getContentPane().add(separator_4);

		JLabel label_1 = new JLabel("<html>学<br>生<br>信<br>息<br>显<br>示");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("华文楷体", Font.BOLD, 30));
		label_1.setBounds(24, 64, 37, 289);
		frame.getContentPane().add(label_1);

		JLabel label_2 = new JLabel("操作台");
		label_2.setFont(new Font("华文楷体", Font.BOLD, 30));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(390, 51, 244, 27);
		frame.getContentPane().add(label_2);

		JLabel lblNewLabel = new JLabel("学号");
		lblNewLabel.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(95, 51, 54, 27);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("姓名");
		lblNewLabel_1.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(95, 93, 54, 21);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("性别");
		lblNewLabel_2.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(95, 133, 54, 27);
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("学院");
		lblNewLabel_3.setEnabled(true);
		lblNewLabel_3.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(95, 170, 54, 34);
		frame.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("专业");
		lblNewLabel_4.setEnabled(true);
		lblNewLabel_4.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(95, 217, 54, 27);
		frame.getContentPane().add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("班别");
		lblNewLabel_5.setEnabled(true);
		lblNewLabel_5.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(95, 254, 54, 27);
		frame.getContentPane().add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("年级");
		lblNewLabel_6.setEnabled(true);
		lblNewLabel_6.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(95, 291, 54, 27);
		frame.getContentPane().add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("生日");
		lblNewLabel_7.setEnabled(true);
		lblNewLabel_7.setFont(new Font("华文楷体", Font.BOLD, 20));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(95, 332, 54, 21);
		frame.getContentPane().add(lblNewLabel_7);

		textField = new JTextField();
		textField.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField.setBackground(Color.LIGHT_GRAY);
		textField.setBounds(155, 51, 148, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_1.setBackground(Color.LIGHT_GRAY);
		textField_1.setBounds(155, 93, 148, 21);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_2.setBackground(Color.LIGHT_GRAY);
		textField_2.setBounds(155, 135, 148, 21);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_3.setBackground(Color.LIGHT_GRAY);
		textField_3.setBounds(155, 179, 148, 21);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_4.setBackground(Color.LIGHT_GRAY);
		textField_4.setBounds(155, 222, 148, 21);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);

		textField_5 = new JTextField();
		textField_5.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_5.setBackground(Color.LIGHT_GRAY);
		textField_5.setBounds(155, 259, 148, 21);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);

		textField_6 = new JTextField();
		textField_6.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_6.setBackground(Color.LIGHT_GRAY);
		textField_6.setBounds(155, 296, 148, 21);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);

		textField_7 = new JTextField();
		textField_7.setFont(new Font("华文楷体", Font.BOLD, 16));
		textField_7.setBackground(Color.LIGHT_GRAY);
		textField_7.setBounds(155, 332, 148, 21);
		frame.getContentPane().add(textField_7);
		textField_7.setColumns(10);

		JLabel label_3 = new JLabel("学号");
		label_3.setFont(new Font("华文楷体", Font.BOLD, 20));
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setBounds(404, 105, 54, 27);
		frame.getContentPane().add(label_3);

		textField_8 = new JTextField();
		textField_8.setFont(new Font("华文楷体", Font.PLAIN, 16));
		textField_8.setBackground(SystemColor.window);
		textField_8.setBounds(468, 110, 138, 21);
		frame.getContentPane().add(textField_8);
		textField_8.setColumns(10);

		JButton btnNewButton = new JButton("查找");
		btnNewButton.addActionListener(new ActionListener() { // 查找学生信息
			public void actionPerformed(ActionEvent e) {
				String Id = textField_8.getText().toString();
				if (Id.isEmpty()) {
					JOptionPane.showMessageDialog(null, "请输入学号进行查询！");
				} else {
					if (Operation.query(Id, Operation.getSt())) {
						JOptionPane.showMessageDialog(null, "查找成功，学生信息如界面所示！");
						Operation.setValue1();
					} else
						JOptionPane.showMessageDialog(null, "查无此人！");
				}
			}
		});
		btnNewButton.setFont(new Font("华文楷体", Font.BOLD, 20));
		btnNewButton.setBounds(516, 151, 90, 27);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("添加学生信息");
		btnNewButton_1.addActionListener(new ActionListener() { // 添加学生信息
			public void actionPerformed(ActionEvent e) {
				ConfirmDlg dlg = new ConfirmDlg();
				dlg.addDlg();
			}
		});
		btnNewButton_1.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton_1.setBounds(365, 221, 138, 34);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("删除学生信息");
		btnNewButton_2.addActionListener(new ActionListener() { // 删除学生信息
			public void actionPerformed(ActionEvent e) {
				ConfirmDlg dlg = new ConfirmDlg();
				dlg.delDlg();
			}
		});
		btnNewButton_2.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton_2.setBounds(513, 221, 138, 34);
		frame.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("修改学生信息");
		btnNewButton_3.addActionListener(new ActionListener() { // 修改学生信息
			public void actionPerformed(ActionEvent e) {
				ConfirmDlg dlg = new ConfirmDlg();
				dlg.updateDlg();
			}
		});
		btnNewButton_3.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton_3.setBounds(365, 295, 138, 34);
		frame.getContentPane().add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("显示所有学生");
		btnNewButton_4.addActionListener(new ActionListener() { // 显示所有学生
			public void actionPerformed(ActionEvent e) {
				if (Operation.show(Operation.getSt()))
					new AllStuDlg();
			}
		});
		btnNewButton_4.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton_4.setBounds(513, 295, 138, 34);
		frame.getContentPane().add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("清屏");
		btnNewButton_5.addActionListener(new ActionListener() { // 清屏
			public void actionPerformed(ActionEvent e) {
				Operation.clean();
			}
		});
		btnNewButton_5.setFont(new Font("华文楷体", Font.BOLD, 20));
		btnNewButton_5.setBounds(578, 10, 93, 23);
		frame.getContentPane().add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("退出登录");
		btnNewButton_6.addActionListener(new ActionListener() { // 退出登录
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "是否退出登录？", "退出程序", JOptionPane.YES_NO_OPTION);
				if (result == 0) {
					frame.dispose();
					LoginView.getDialog().setVisible(true);
				}
			}
		});
		btnNewButton_6.setFont(new Font("华文楷体", Font.BOLD, 20));
		btnNewButton_6.setBounds(10, 391, 124, 32);
		frame.getContentPane().add(btnNewButton_6);

		JButton btnNewButton_7 = new JButton("退出程序");
		btnNewButton_7.addActionListener(new ActionListener() { // 退出程序
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "是否退出程序？", "退出程序", JOptionPane.YES_NO_OPTION);
				if (result == 0)
					Operation.exit(Operation.getSt(), Operation.getConn());
			}
		});
		btnNewButton_7.setFont(new Font("华文楷体", Font.BOLD, 20));
		btnNewButton_7.setBounds(547, 390, 124, 33);
		frame.getContentPane().add(btnNewButton_7);
		frame.setVisible(true);
	}

	/**
	 * JTextField的Get方法
	 */
	public static JTextField getTextField() {
		return textField;
	}

	public static JTextField getTextField_1() {
		return textField_1;
	}

	public static JTextField getTextField_2() {
		return textField_2;
	}

	public static JTextField getTextField_3() {
		return textField_3;
	}

	public static JTextField getTextField_4() {
		return textField_4;
	}

	public static JTextField getTextField_5() {
		return textField_5;
	}

	public static JTextField getTextField_6() {
		return textField_6;
	}

	public static JTextField getTextField_7() {
		return textField_7;
	}

	public static JTextField getTextField_8() {
		return textField_8;
	}

}
