package 学生信息管理;

import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * 学生信息管理程序 启动
 * 
 * @author 508工作室
 *
 */
public class STUManager {

	public static void main(String[] args) {

		try {
			Operation.setSt(Operation.getConn().createStatement()); // st=conn.createStatement;
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			// e.printStackTrace();
			JOptionPane.showMessageDialog(null, "连接数据库失败");
		}

		new LoginView();
	}

}
