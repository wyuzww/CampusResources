package 学生信息管理;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 确认学生学号窗口
 * 
 * @author 508工作室
 *
 */
public class ConfirmDlg {
	private static JDialog dialog = new JDialog();
	private static JButton btnNewButton;
	private static JTextField textField;
	private static JLabel label;
	private static String order;

	/**
	 * Create the dialog.
	 */
	public ConfirmDlg() {

	}

	private void init() {
		dialog.setModal(true);
		dialog.setResizable(false);

		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setSize(272, 126);
		// dialog.setBounds(100, 100, 272, 126);
		dialog.getContentPane().setLayout(null);

		label = new JLabel("请输入要" + order + "的学生的学号：");
		label.setFont(new Font("华文楷体", Font.BOLD, 18));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(0, 0, 266, 24);
		dialog.getContentPane().add(label);

		textField = new JTextField();
		textField.setFont(new Font("华文楷体", Font.PLAIN, 16));
		textField.setBounds(54, 34, 145, 21);
		dialog.getContentPane().add(textField);
		textField.setColumns(10);

		btnNewButton = new JButton("确定");
		btnNewButton.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton.setBounds(22, 68, 93, 23);
		dialog.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("取消");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("华文楷体", Font.BOLD, 16));
		btnNewButton_1.setBounds(151, 68, 93, 23);
		dialog.getContentPane().add(btnNewButton_1);
		dialog.setLocationRelativeTo(null);// 视图居中
	}

	void delDlg() {
		dialog.getContentPane().removeAll();
		order = "删除";
		init();
		dialog.setTitle("删除学生信息");

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Id = textField.getText().toString();
				if (Id.equals("")) {
					JOptionPane.showMessageDialog(null, "请输入要删除的学号！");
				} else {
					if (Operation.query(Id, Operation.getSt())) {
						int result = JOptionPane.showConfirmDialog(null, "是否删除学号为" + Id + "的信息？", "确认删除",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							if (Operation.del(Id, Operation.getSt())) {
								JOptionPane.showMessageDialog(null, "删除成功！删除的学生信息如界面显示！");
								dialog.dispose();
								Operation.setValue1();
							} else {
								JOptionPane.showMessageDialog(null, "删除失败！");
								dialog.dispose();
							}
						}
					} else {
						JOptionPane.showMessageDialog(null, "查无此人！");
					}
				}
			}
		});
		dialog.setVisible(true);
		dialog.setLocationRelativeTo(null);// 视图居中
	}

	void addDlg() {
		dialog.getContentPane().removeAll();
		order = "添加";
		init();
		dialog.setTitle("添加学生信息");

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Id = textField.getText().toString();
				if (Id.isEmpty()) {
					JOptionPane.showMessageDialog(null, "请输入要添加的学号！");
				} else {
					if (Operation.query(Id, Operation.getSt())) {
						JOptionPane.showMessageDialog(null, "该学生已存在！");
					} else {
						JOptionPane.showMessageDialog(null, "请继续填写学生信息！");
						dialog.dispose();
						StuInfoDlg.stuadd();
					}
				}
			}
		});
		dialog.setVisible(true);
	}

	void updateDlg() {
		dialog.getContentPane().removeAll();
		order = "修改";
		init();
		dialog.setTitle("修改学生信息");

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Id = textField.getText().toString();
				if (Id.equals("")) {
					JOptionPane.showMessageDialog(null, "请输入要修改的学号！");
				} else {
					if (Operation.query(Id, Operation.getSt())) {
						dialog.dispose();
						StuInfoDlg.stuupdate();
					} else {
						JOptionPane.showMessageDialog(null, "查无此人！");
					}
				}
			}
		});
		dialog.setVisible(true);
	}

}
