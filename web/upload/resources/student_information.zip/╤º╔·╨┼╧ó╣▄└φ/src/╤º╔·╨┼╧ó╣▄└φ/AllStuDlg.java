package 学生信息管理;

import javax.swing.JDialog;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Color;

/**
 * 所有学生信息视图
 * 
 * @author 508工作室
 *
 */
@SuppressWarnings("serial")
public class AllStuDlg extends JDialog {
	private final static JTextArea textArea = new JTextArea();

	/**
	 * Create the dialog.
	 * 
	 * @return
	 */
	public AllStuDlg() {
		getContentPane().setEnabled(false);
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setBackground(Color.LIGHT_GRAY);
		setResizable(false);
		setModal(true);
		getContentPane().setFont(new Font("华文楷体", Font.PLAIN, 16));
		setTitle("所有学生信息");
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 408, 440);
		getContentPane().setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setLocation(0, 0);
		scrollPane.setEnabled(false);
		scrollPane.setSize(402, 411);
		// scrollPane.setBounds(0, 0, 402, 414);
		getContentPane().add(scrollPane);
		scrollPane.setViewportView(getTextArea());
		setLocationRelativeTo(null);// 视图居中
		setVisible(true);
	}

	/**
	 * @return textArea
	 */
	public static JTextArea getTextArea() {
		return textArea;
	}
}
