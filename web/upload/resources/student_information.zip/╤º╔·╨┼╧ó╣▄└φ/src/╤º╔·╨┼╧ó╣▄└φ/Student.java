package 学生信息管理;

/**
 * 学生类
 * 
 * @author 508工作室
 *
 */
public class Student {
	private static String id;
	private static String name;
	private static String gender;
	private static String academy;
	private static String major;
	private static String classid;
	private static String grade;
	private static String birthday;

	/**
	 * set、get方法
	 */
	public static String getId() {
		return id;
	}

	public static void setId(String id) {
		Student.id = id;
	}

	public static String getName() {
		return name;
	}

	public static void setName(String name) {
		Student.name = name;
	}

	public static String getGender() {
		return gender;
	}

	public static void setGender(String gender) {
		Student.gender = gender;
	}

	public static String getAcademy() {
		return academy;
	}

	public static void setAcademy(String academy) {
		Student.academy = academy;
	}

	public static String getMajor() {
		return major;
	}

	public static void setMajor(String major) {
		Student.major = major;
	}

	public static String getClassid() {
		return classid;
	}

	public static void setClassid(String classid) {
		Student.classid = classid;
	}

	public static String getGrade() {
		return grade;
	}

	public static void setGrade(String grade) {
		Student.grade = grade;
	}

	public static String getBirthday() {
		return birthday;
	}

	public static void setBirthday(String birthday) {
		Student.birthday = birthday;
	}

}
