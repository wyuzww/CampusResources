package 学生信息管理;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 学生信息填写视图
 * 
 * @author 508工作室
 *
 */
public class StuInfoDlg {
	private static JDialog dialog = new JDialog();
	private static JButton btnNewButton;
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	private static JTextField textField_4;
	private static JTextField textField_5;
	private static JTextField textField_6;
	private static JTextField textField_7;

	private static String Id;
	private static String Name;
	private static String Gender;
	private static String Academy;
	private static String Major;
	private static String Classid;
	private static String Grade;
	private static String Birthday;

	public StuInfoDlg() {

	}

	/**
	 * Create the dialog.
	 * 
	 * @return
	 */
	private static void init() {
		dialog.setResizable(false);
		dialog.setModal(true);
		dialog.setBounds(100, 100, 242, 305);
		dialog.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("学号");
		lblNewLabel.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 10, 54, 15);
		dialog.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("姓名");
		lblNewLabel_1.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 40, 54, 15);
		dialog.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("性别");
		lblNewLabel_2.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(10, 65, 54, 22);
		dialog.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("学院");
		lblNewLabel_3.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(10, 94, 54, 25);
		dialog.getContentPane().add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("专业");
		lblNewLabel_4.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(10, 129, 54, 15);
		dialog.getContentPane().add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("班别");
		lblNewLabel_5.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(10, 154, 54, 25);
		dialog.getContentPane().add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("年级");
		lblNewLabel_6.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(10, 189, 54, 15);
		dialog.getContentPane().add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("生日");
		lblNewLabel_7.setFont(new Font("华文楷体", Font.BOLD, 15));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(10, 217, 54, 15);
		dialog.getContentPane().add(lblNewLabel_7);

		textField = new JTextField();
		textField.setBounds(67, 7, 129, 21);
		dialog.getContentPane().add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(67, 35, 129, 21);
		dialog.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(67, 66, 129, 21);
		dialog.getContentPane().add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(67, 96, 129, 21);
		dialog.getContentPane().add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setBounds(67, 126, 129, 21);
		dialog.getContentPane().add(textField_4);
		textField_4.setColumns(10);

		textField_5 = new JTextField();
		textField_5.setBounds(67, 156, 129, 21);
		dialog.getContentPane().add(textField_5);
		textField_5.setColumns(10);

		textField_6 = new JTextField();
		textField_6.setBounds(67, 186, 129, 21);
		dialog.getContentPane().add(textField_6);
		textField_6.setColumns(10);

		textField_7 = new JTextField();
		textField_7.setBounds(67, 214, 129, 21);
		dialog.getContentPane().add(textField_7);
		textField_7.setColumns(10);

		btnNewButton = new JButton("确定");
		btnNewButton.setFont(new Font("华文楷体", Font.BOLD, 15));
		btnNewButton.setBounds(10, 245, 93, 23);
		dialog.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("取消");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "是否取消操作？", "取消操作", JOptionPane.YES_NO_OPTION);
				if (result == 0)
					dialog.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("华文楷体", Font.BOLD, 15));
		btnNewButton_1.setBounds(133, 245, 93, 23);
		dialog.getContentPane().add(btnNewButton_1);
		Operation.setValue2();
	}

	static void gettext() {
		Id = textField.getText().toString();
		Name = textField_1.getText().toString();
		Gender = textField_2.getText().toString();
		Academy = textField_3.getText().toString();
		Major = textField_4.getText().toString();
		Classid = textField_5.getText().toString();
		Grade = textField_6.getText().toString();
		Birthday = textField_7.getText().toString();
	}

	static void stuadd() {
		dialog.getContentPane().removeAll();
		dialog.setTitle("添加学生信息");
		init();

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gettext();
				if (Id.isEmpty() || Name.isEmpty() || Gender.isEmpty() || Academy.isEmpty() || Major.isEmpty()
						|| Classid.isEmpty() || Grade.isEmpty() || Birthday.isEmpty()) {
					JOptionPane.showMessageDialog(null, "请填写完整！");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "是否添加" + Id + "学生信息？", "添加学生信息",
							JOptionPane.YES_NO_OPTION);
					if (result == 0) {
						if (Operation.query(Id, Operation.getSt())) {
							JOptionPane.showMessageDialog(null, "学号已存在！");
						} else if (Operation.add(Id, Name, Gender, Academy, Major, Classid, Grade, Birthday,
								Operation.getSt())) {
							if (Operation.query(Id, Operation.getSt())) {
								JOptionPane.showMessageDialog(null, "添加成功！学生信息如界面所示");
								Operation.setValue1();
								dialog.dispose();
							}
						}
					}
				}
			}
		});
		dialog.setLocationRelativeTo(null);// 视图居中
		dialog.setVisible(true);
	}

	static void stuupdate() {
		dialog.getContentPane().removeAll();
		dialog.setTitle("修改学生信息");
		init();

		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gettext();
				if (Id.isEmpty() || Name.isEmpty() || Gender.isEmpty() || Academy.isEmpty() || Major.isEmpty()
						|| Classid.isEmpty() || Grade.isEmpty() || Birthday.isEmpty()) {
					JOptionPane.showMessageDialog(null, "请填写完整！");
				} else {
					int result = JOptionPane.showConfirmDialog(null, "是否修改" + Id + "学生信息？", "修改学生信息",
							JOptionPane.YES_NO_OPTION);
					if (result == 0) {
						if (Id.compareTo(Student.getId()) != 0 && Operation.query(Id, Operation.getSt())) {
							JOptionPane.showMessageDialog(null, "学号已存在！");
						} else if (Operation.update(Id, Name, Gender, Academy, Major, Classid, Grade, Birthday,
								Operation.getSt())) {
							if (Operation.query(Id, Operation.getSt())) {
								JOptionPane.showMessageDialog(null, "修改成功！学生信息如界面所示");
								Operation.setValue1();
								dialog.dispose();
							}
						}
					}
				}
			}
		});
		dialog.setLocationRelativeTo(null);// 视图居中
		dialog.setVisible(true);
	}

	/**
	 * JTextField的Get方法
	 * 
	 * @return
	 */
	public static JTextField getTextField() {
		return textField;
	}

	public static JTextField getTextField_1() {
		return textField_1;
	}

	public static JTextField getTextField_2() {
		return textField_2;
	}

	public static JTextField getTextField_3() {
		return textField_3;
	}

	public static JTextField getTextField_4() {
		return textField_4;
	}

	public static JTextField getTextField_5() {
		return textField_5;
	}

	public static JTextField getTextField_6() {
		return textField_6;
	}

	public static JTextField getTextField_7() {
		return textField_7;
	}

}
