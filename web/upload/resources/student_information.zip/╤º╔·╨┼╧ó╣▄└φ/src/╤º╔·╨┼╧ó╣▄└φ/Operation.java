package 学生信息管理;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 * 学生信息管理程序 操作中心
 * 
 * @author 508工作室
 *
 */
public class Operation {
	private static Connection conn = Operation.getConnection();
	private static Statement st = null;

	/**
	 * 加载驱动，连接数据库
	 */
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			JOptionPane.showMessageDialog(null, "未找到数据库驱动");
		}
		String url = "jdbc:mysql://localhost:3306/stuinfo?characterEncoding=utf8&useSSL=true";
		String user = "myuser";
		String password = "123456";
		try {
			return DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			JOptionPane.showMessageDialog(null, "连接数据库失败");
			return null;
		}
	}

	/**
	 * 查找
	 */
	public static boolean query(String Id, Statement st) {
		Student.setId(null);
		Student.setName(null);
		Student.setGender(null);
		Student.setAcademy(null);
		Student.setMajor(null);
		Student.setClassid(null);
		Student.setGrade(null);
		Student.setBirthday(null);
		try {
			String sql = "select * from stuinfo where id=" + Id + "";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				Student.setId(rs.getString(1));
				Student.setName(rs.getString(2));
				Student.setGender(rs.getString(3));
				Student.setAcademy(rs.getString(4));
				Student.setMajor(rs.getString(5));
				Student.setClassid(rs.getString(6));
				Student.setGrade(rs.getString(7));
				Student.setBirthday(rs.getString(8));
			}
			if (Id.equals(Student.getId())) {
				return true;
			} else
				return false;

		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			// e.printStackTrace();
			return false; // 这个return存在没意义
		}
	}

	/**
	 * 添加学生信息
	 */
	public static boolean add(String Id, String Name, String Gender, String Academy, String Major, String Classid,
			String Grade, String Birthday, Statement st) {
		String sql = "insert into stuinfo(id,name,gender,academy,major,classid,grade,birthday) " + "values('" + Id
				+ "','" + Name + "','" + Gender + "','" + Academy + "','" + Major + "','" + Classid + "','" + Grade
				+ "','" + Birthday + "')";
		try {
			st.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 删除学生信息
	 */
	public static boolean del(String Id, Statement st) {
		String sql = "delete from stuinfo where id=" + Id + "";
		try {
			st.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 修改学生信息
	 */
	public static boolean update(String Id, String Name, String Gender, String Academy, String Major, String Classid,
			String Grade, String Birthday, Statement st) {
		String sql = "update stuinfo set id='" + Id + "'," + "name='" + Name + "'," + "gender='" + Gender + "',"
				+ "academy='" + Academy + "'," + "major='" + Major + "'," + "classid='" + Classid + "'," + "grade='"
				+ Grade + "'," + "birthday='" + Birthday + "' where id='" + Student.getId() + "'";
		try {
			st.executeUpdate(sql);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 显示学生信息
	 */
	public static boolean show(Statement st) {
		String sql = "select * from stuinfo";
		try {
			ResultSet rs = st.executeQuery(sql);
			AllStuDlg.getTextArea().setText(""); // 清空textArea
			AllStuDlg.getTextArea().append("\n" + "学号" + "	" + "姓名" + "	" + "性别" + "	" + "学院" + "	" + "专业"
					+ "	" + "班别" + "	" + "年级" + "	" + "生日" + "\n");
			AllStuDlg.getTextArea().append("————" + "————" + "————" + "————" + "————" + "————" + "————" + "————"
					+ "—————" + "————" + "————" + "————" + "————" + "——————" + "\n");
			while (rs.next()) {
				Student.setId(rs.getString(1));
				Student.setName(rs.getString(2));
				Student.setGender(rs.getString(3));
				Student.setAcademy(rs.getString(4));
				Student.setMajor(rs.getString(5));
				Student.setClassid(rs.getString(6));
				Student.setGrade(rs.getString(7));
				Student.setBirthday(rs.getString(8));
				AllStuDlg.getTextArea()
						.append(Student.getId() + "	" + Student.getName() + "	" + Student.getGender() + "	"
								+ Student.getAcademy() + "	" + Student.getMajor() + "	" + Student.getClassid()
								+ "	" + Student.getGrade() + "	" + Student.getBirthday() + "\n");
			}
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return false;
		}
	}

	/**
	 * 清屏
	 */
	public static void clean() {
		MainView.getTextField().setText("");
		MainView.getTextField_1().setText("");
		MainView.getTextField_2().setText("");
		MainView.getTextField_3().setText("");
		MainView.getTextField_4().setText("");
		MainView.getTextField_5().setText("");
		MainView.getTextField_6().setText("");
		MainView.getTextField_7().setText("");
		MainView.getTextField_8().setText("");
	}

	/**
	 * 编辑框 置值
	 */
	public static void setValue1() {
		MainView.getTextField().setText(Student.getId());
		MainView.getTextField_1().setText(Student.getName());
		MainView.getTextField_2().setText(Student.getGender());
		MainView.getTextField_3().setText(Student.getAcademy());
		MainView.getTextField_4().setText(Student.getMajor());
		MainView.getTextField_5().setText(Student.getClassid());
		MainView.getTextField_6().setText(Student.getGrade());
		MainView.getTextField_7().setText(Student.getBirthday());
		MainView.getTextField_8().setText("");
	}

	public static void setValue2() {
		StuInfoDlg.getTextField().setText(Student.getId());
		StuInfoDlg.getTextField_1().setText(Student.getName());
		StuInfoDlg.getTextField_2().setText(Student.getGender());
		StuInfoDlg.getTextField_3().setText(Student.getAcademy());
		StuInfoDlg.getTextField_4().setText(Student.getMajor());
		StuInfoDlg.getTextField_5().setText(Student.getClassid());
		StuInfoDlg.getTextField_6().setText(Student.getGrade());
		StuInfoDlg.getTextField_7().setText(Student.getBirthday());
	}

	/**
	 * 断开连接，退出程序
	 */
	public static void exit(Statement st, Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (st != null) {
			try {
				st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.exit(0);
	}

	/**
	 * get、set 方法
	 */
	public static Connection getConn() {
		return conn;
	}

	public static Statement getSt() {
		return st;
	}

	public static void setSt(Statement st) {
		Operation.st = st;
	}

}
