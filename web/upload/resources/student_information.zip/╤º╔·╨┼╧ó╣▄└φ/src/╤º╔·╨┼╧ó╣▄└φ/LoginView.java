package 学生信息管理;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 登录视图
 * 
 * @author 508工作室
 *
 */
public class LoginView {
	private static JDialog dialog;
	private JTextField textField;
	private JPasswordField passwordField;

	public LoginView() {
		init();
	}

	/**
	 * Create the dialog.
	 */
	private void init() {
		dialog = new JDialog();
		// dialog.setModal(true);
		getDialog().setResizable(false);
		getDialog().addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) { // 鼠标点击关闭时
				int result = JOptionPane.showConfirmDialog(null, "是否退出程序？", "退出程序", JOptionPane.YES_NO_OPTION);
				if (result == 0)
					Operation.exit(Operation.getSt(), Operation.getConn());
				else
					getDialog().setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			}
		});
		getDialog().getContentPane().setBackground(SystemColor.menu);
		getDialog().setFont(new Font("华文楷体", Font.BOLD, 13));
		getDialog().getContentPane().setFont(new Font("宋体", Font.PLAIN, 13));
		getDialog().getContentPane().setForeground(Color.BLACK);
		getDialog().setTitle("学生信息管理");
		getDialog().setBackground(Color.WHITE);
		getDialog().setSize(288, 203);
		// dialog.setBounds(100, 100, 288, 203);
		getDialog().getContentPane().setLayout(null);

		JLabel Label = new JLabel("管理员登录");
		Label.setBackground(Color.BLACK);
		Label.setForeground(Color.BLACK);
		Label.setFont(new Font("华文楷体", Font.BOLD, 18));
		Label.setHorizontalAlignment(SwingConstants.CENTER);
		Label.setBounds(84, 10, 111, 34);
		getDialog().getContentPane().add(Label);

		JLabel Label1 = new JLabel("帐号");
		Label1.setBackground(Color.BLACK);
		Label1.setForeground(Color.BLACK);
		Label1.setFont(new Font("华文楷体", Font.BOLD, 16));
		Label1.setHorizontalAlignment(SwingConstants.CENTER);
		Label1.setBounds(23, 68, 54, 15);
		getDialog().getContentPane().add(Label1);

		JLabel label2 = new JLabel("密码");
		label2.setForeground(Color.BLACK);
		label2.setBackground(Color.BLACK);
		label2.setFont(new Font("华文楷体", Font.BOLD, 16));
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		label2.setBounds(23, 103, 54, 15);
		getDialog().getContentPane().add(label2);

		textField = new JTextField();
		textField.setFont(new Font("华文楷体", Font.PLAIN, 13));
		textField.setBounds(84, 64, 111, 21);
		getDialog().getContentPane().add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setFont(new Font("华文楷体", Font.PLAIN, 13));
		passwordField.setBounds(84, 99, 111, 21);
		getDialog().getContentPane().add(passwordField);

		JButton NewButton = new JButton("登录");
		NewButton.setForeground(Color.BLACK);
		NewButton.setBackground(Color.LIGHT_GRAY);
		NewButton.setFont(new Font("华文楷体", Font.BOLD, 15));
		NewButton.addActionListener(new ActionListener() { // 登录
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String zhanghao = textField.getText().toString();
				String mima = passwordField.getText().toString();

				if (zhanghao.equals("") || mima.equals("")) {
					JOptionPane.showMessageDialog(null, "请填写完整！");
				}

				else {
					if (zhanghao.equals("Admin")) {
						if (mima.equals("123456")) {
							getDialog().setVisible(false);
							// dialog.dispose();
							new MainView();
						} else {
							JOptionPane.showMessageDialog(null, "密码错误！");
						}
					} else {
						JOptionPane.showMessageDialog(null, "帐号错误！");
					}
				}
			}
		});
		NewButton.setBounds(49, 146, 70, 23);
		getDialog().getContentPane().add(NewButton);

		JButton NewButton1 = new JButton("取消");
		NewButton1.setForeground(Color.BLACK);
		NewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "是否退出程序？", "退出程序", JOptionPane.YES_NO_OPTION);
				if (result == 0)
					Operation.exit(Operation.getSt(), Operation.getConn());
			}
		});
		NewButton1.setBackground(Color.LIGHT_GRAY);
		NewButton1.setFont(new Font("华文楷体", Font.BOLD, 15));
		NewButton1.setBounds(152, 146, 70, 23);
		getDialog().getContentPane().add(NewButton1);
		getDialog().setVisible(true);
		getDialog().setLocationRelativeTo(null); // 视图居中
	}

	public static JDialog getDialog() {
		return dialog;
	}
}
